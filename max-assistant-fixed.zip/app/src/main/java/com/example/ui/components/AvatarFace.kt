package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow

/** Current emotion of the on-screen character. Set by the AI brain or guessed from the spoken text. */
object AvatarState {
    val emotion = MutableStateFlow("neutral")
    @Volatile private var manualUntil = 0L
    @Volatile var lastChange = System.currentTimeMillis()

    private fun normalize(e: String): String = when (e.lowercase()) {
        "happy", "sad", "angry", "surprised", "thinking", "love", "sleepy" -> e.lowercase()
        else -> "neutral"
    }

    fun setManual(e: String) {
        emotion.value = normalize(e)
        manualUntil = System.currentTimeMillis() + 15000L
        lastChange = System.currentTimeMillis()
    }

    fun autoFrom(text: String) {
        if (System.currentTimeMillis() < manualUntil) return
        emotion.value = guess(text)
        lastChange = System.currentTimeMillis()
    }

    fun reset() {
        emotion.value = "neutral"
    }

    fun guess(text: String): String {
        val t = text.lowercase()
        return when {
            t.contains("haha") || t.contains("wah") || t.contains("badhiya") || t.contains("mubarak") ||
                    t.contains("great") || t.contains("khushi") || t.contains("mazaa") -> "happy"
            t.contains("sorry") || t.contains("maaf") || t.contains("dukh") || t.contains("udaas") ||
                    t.contains("nahi ho paya") || t.contains("nahi mila") -> "sad"
            t.contains("arre") || t.contains("wow") || t.contains("kya baat") -> "surprised"
            t.contains("pyaar") || t.contains("love") || t.contains("dil se") -> "love"
            t.contains("shubh ratri") || t.contains("good night") || t.contains("neend") -> "sleepy"
            t.contains("soch") || t.contains("hmm") || t.contains("dhundh raha") -> "thinking"
            else -> "neutral"
        }
    }
}

@Composable
fun AvatarFace(
    isFemale: Boolean,
    emotion: String,
    speaking: Boolean,
    modifier: Modifier = Modifier,
    avatarSize: Dp = 170.dp
) {
    var eyesClosed by remember { mutableStateOf(false) }
    var mouth by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(2800)
            eyesClosed = true
            delay(130)
            eyesClosed = false
        }
    }
    LaunchedEffect(speaking) {
        if (speaking) {
            while (true) {
                mouth = 1f
                delay(130)
                mouth = 0.3f
                delay(110)
                mouth = 0.75f
                delay(120)
                mouth = 0.15f
                delay(110)
            }
        } else {
            mouth = 0f
        }
    }

    Canvas(modifier = modifier.size(avatarSize)) {
        drawAvatar(isFemale, emotion, eyesClosed, mouth)
    }
}

private fun DrawScope.drawAvatar(isFemale: Boolean, emotion: String, eyesClosed: Boolean, mouth: Float) {
    val s = size.minDimension
    val cx = s / 2f
    val cy = s * 0.55f
    val skin = Color(0xFFFFE3D1)
    val hair = if (isFemale) Color(0xFF7C4DFF) else Color(0xFF1F2A55)
    val hairDark = if (isFemale) Color(0xFF5B34D6) else Color(0xFF141B3D)
    val iris = if (isFemale) Color(0xFFFF4F9A) else Color(0xFF00BFA5)
    val line = Color(0xFF3B2A3F)
    val mouthColor = Color(0xFF8E2040)

    // soft glow behind the character
    drawCircle(color = Color(0x2200E5FF), radius = s * 0.48f, center = Offset(cx, s * 0.5f))

    // back hair
    if (isFemale) {
        drawRoundRect(
            color = hairDark,
            topLeft = Offset(cx - s * 0.36f, cy - s * 0.36f),
            size = Size(s * 0.72f, s * 0.86f),
            cornerRadius = CornerRadius(s * 0.30f, s * 0.30f)
        )
    } else {
        drawCircle(color = hairDark, radius = s * 0.37f, center = Offset(cx, cy - s * 0.02f))
        for (i in -1..1) {
            val spike = Path().apply {
                moveTo(cx + i * s * 0.12f - s * 0.07f, cy - s * 0.34f)
                lineTo(cx + i * s * 0.12f, cy - s * 0.50f)
                lineTo(cx + i * s * 0.12f + s * 0.07f, cy - s * 0.34f)
                close()
            }
            drawPath(spike, color = hairDark)
        }
    }

    // face
    drawOval(color = skin, topLeft = Offset(cx - s * 0.30f, cy - s * 0.33f), size = Size(s * 0.60f, s * 0.66f))

    // bangs
    val bangs = Path().apply {
        moveTo(cx - s * 0.33f, cy - s * 0.05f)
        quadraticBezierTo(cx - s * 0.36f, cy - s * 0.42f, cx, cy - s * 0.40f)
        quadraticBezierTo(cx + s * 0.36f, cy - s * 0.42f, cx + s * 0.33f, cy - s * 0.05f)
        lineTo(cx + s * 0.22f, cy - s * 0.17f)
        lineTo(cx + s * 0.12f, cy - s * 0.06f)
        lineTo(cx + s * 0.03f, cy - s * 0.19f)
        lineTo(cx - s * 0.08f, cy - s * 0.07f)
        lineTo(cx - s * 0.18f, cy - s * 0.19f)
        lineTo(cx - s * 0.25f, cy - s * 0.08f)
        close()
    }
    drawPath(bangs, color = hair)
    if (isFemale) {
        drawCircle(Color(0xFFFF80AB), s * 0.04f, Offset(cx - s * 0.33f, cy - s * 0.2f))
        drawCircle(Color(0xFFFF80AB), s * 0.04f, Offset(cx + s * 0.33f, cy - s * 0.2f))
    }

    val happy = emotion == "happy" || emotion == "love"

    for (side in listOf(-1f, 1f)) {
        val ecx = cx + side * s * 0.13f
        val ecy = cy + s * 0.03f

        // eyes
        if (eyesClosed || happy || emotion == "sleepy") {
            drawArc(
                color = line,
                startAngle = if (happy) 200f else 20f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(ecx - s * 0.065f, ecy - s * 0.04f),
                size = Size(s * 0.13f, s * 0.09f),
                style = Stroke(width = s * 0.018f, cap = StrokeCap.Round)
            )
        } else {
            val big = if (emotion == "surprised") 1.25f else 1f
            val w = s * 0.115f * big
            val h = s * 0.15f * big
            val shiftX = if (emotion == "thinking") s * 0.02f else 0f
            val shiftY = if (emotion == "thinking") -s * 0.02f else 0f
            drawOval(Color.White, Offset(ecx - w / 2, ecy - h / 2), Size(w, h))
            drawOval(iris, Offset(ecx - w * 0.38f + shiftX, ecy - h * 0.40f + shiftY), Size(w * 0.76f, h * 0.8f))
            drawOval(Color(0xFF222222), Offset(ecx - w * 0.18f + shiftX, ecy - h * 0.18f + shiftY), Size(w * 0.36f, h * 0.36f))
            drawCircle(Color.White, s * 0.012f * big, Offset(ecx - w * 0.12f + shiftX, ecy - h * 0.22f + shiftY))
            drawOval(line, Offset(ecx - w / 2, ecy - h / 2), Size(w, h), style = Stroke(width = s * 0.008f))
        }

        // eyebrows
        val browY = ecy - s * 0.105f
        var inner = browY
        var outer = browY
        when (emotion) {
            "angry" -> { inner += s * 0.025f; outer -= s * 0.01f }
            "sad" -> { inner -= s * 0.02f; outer += s * 0.015f }
            "surprised" -> { inner -= s * 0.03f; outer -= s * 0.03f }
            "thinking" -> if (side > 0) { inner -= s * 0.03f; outer -= s * 0.03f }
        }
        drawLine(
            color = hairDark,
            start = Offset(ecx - side * s * 0.045f, inner),
            end = Offset(ecx + side * s * 0.055f, outer),
            strokeWidth = s * 0.016f,
            cap = StrokeCap.Round
        )

        // blush
        val blush = if (happy) 0.55f else 0.25f
        drawOval(
            Color(0xFFFF8A80).copy(alpha = blush),
            Offset(cx + side * s * 0.19f - s * 0.05f, cy + s * 0.12f),
            Size(s * 0.1f, s * 0.05f)
        )

        // tear
        if (emotion == "sad" && side > 0) {
            drawOval(Color(0xFF80D8FF), Offset(ecx + s * 0.01f, ecy + s * 0.07f), Size(s * 0.02f, s * 0.035f))
        }
    }

    // mouth
    val my = cy + s * 0.17f
    if (mouth > 0.05f) {
        val w = s * 0.09f
        val h = s * 0.07f * mouth + s * 0.01f
        drawOval(mouthColor, Offset(cx - w / 2, my - h / 2), Size(w, h))
    } else {
        when (emotion) {
            "happy", "love" -> drawArc(
                color = line, startAngle = 20f, sweepAngle = 140f, useCenter = false,
                topLeft = Offset(cx - s * 0.07f, my - s * 0.05f), size = Size(s * 0.14f, s * 0.09f),
                style = Stroke(width = s * 0.014f, cap = StrokeCap.Round)
            )
            "sad" -> drawArc(
                color = line, startAngle = 200f, sweepAngle = 140f, useCenter = false,
                topLeft = Offset(cx - s * 0.05f, my - s * 0.005f), size = Size(s * 0.10f, s * 0.06f),
                style = Stroke(width = s * 0.014f, cap = StrokeCap.Round)
            )
            "surprised" -> drawOval(mouthColor, Offset(cx - s * 0.025f, my - s * 0.03f), Size(s * 0.05f, s * 0.06f))
            "angry" -> drawLine(
                color = line, start = Offset(cx - s * 0.045f, my + s * 0.01f), end = Offset(cx + s * 0.045f, my),
                strokeWidth = s * 0.014f, cap = StrokeCap.Round
            )
            else -> drawArc(
                color = line, startAngle = 25f, sweepAngle = 130f, useCenter = false,
                topLeft = Offset(cx - s * 0.04f, my - s * 0.03f), size = Size(s * 0.08f, s * 0.05f),
                style = Stroke(width = s * 0.012f, cap = StrokeCap.Round)
            )
        }
    }
}
