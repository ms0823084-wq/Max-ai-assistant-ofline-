package com.example.ui.screens

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.service.AntiTheftDeviceAdminReceiver
import com.example.service.MaxAccessibilityService
import com.example.service.WhatsAppNotificationListener
import com.example.ui.theme.BrightCoral
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class PermissionItem(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val isGranted: Boolean,
    val onAction: () -> Unit
)

@Composable
fun PermissionsScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var refreshTrigger by remember { mutableStateOf(0) }

    val multiPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshTrigger++
    }

    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val adminComponent = ComponentName(context, AntiTheftDeviceAdminReceiver::class.java)
    val isDeviceAdminActive = dpm.isAdminActive(adminComponent)

    val isAccessibilityActive = MaxAccessibilityService.isServiceRunning
    val isNotificationListenerActive = WhatsAppNotificationListener.isServiceRunning

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    val isIgnoringBatteryOptimizations = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        powerManager.isIgnoringBatteryOptimizations(context.packageName)
    } else true

    val hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else true

    fun checkPermission(perm: String): Boolean {
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    }

    val permissionsList = listOf(
        PermissionItem(
            title = "Microphone",
            description = "For continuous hands-free wake word ('Bolo Max') and voice commands.",
            icon = Icons.Default.Mic,
            isGranted = checkPermission(Manifest.permission.RECORD_AUDIO),
            onAction = { multiPermissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
        ),
        PermissionItem(
            title = "Camera",
            description = "For Gemini Vision 'ye kya hai' identification and silent intruder selfies.",
            icon = Icons.Default.CameraAlt,
            isGranted = checkPermission(Manifest.permission.CAMERA),
            onAction = { multiPermissionLauncher.launch(arrayOf(Manifest.permission.CAMERA)) }
        ),
        PermissionItem(
            title = "Contacts",
            description = "To find contacts for WhatsApp messaging and hands-free calling.",
            icon = Icons.Default.Contacts,
            isGranted = checkPermission(Manifest.permission.READ_CONTACTS),
            onAction = { multiPermissionLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS)) }
        ),
        PermissionItem(
            title = "Location (GPS)",
            description = "To attach exact coordinates to anti-theft intruder alerts.",
            icon = Icons.Default.LocationOn,
            isGranted = checkPermission(Manifest.permission.ACCESS_FINE_LOCATION),
            onAction = { multiPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
        ),
        PermissionItem(
            title = "Phone Calling",
            description = "To make voice calls hands-free after spoken confirmation.",
            icon = Icons.Default.Call,
            isGranted = checkPermission(Manifest.permission.CALL_PHONE),
            onAction = { multiPermissionLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE)) }
        ),
        PermissionItem(
            title = "Notifications",
            description = "To display the always-listening service and anti-theft alerts.",
            icon = Icons.Default.Notifications,
            isGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) checkPermission(Manifest.permission.POST_NOTIFICATIONS) else true,
            onAction = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    multiPermissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                }
            }
        ),
        PermissionItem(
            title = "Accessibility Service",
            description = "Essential for screen gestures, OCR tapping, and phone navigation.",
            icon = Icons.Default.TouchApp,
            isGranted = isAccessibilityActive,
            onAction = {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        ),
        PermissionItem(
            title = "Notification Listener",
            description = "Reads incoming WhatsApp messages aloud and enables auto-reply bot.",
            icon = Icons.Default.Notifications,
            isGranted = isNotificationListenerActive,
            onAction = {
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        ),
        PermissionItem(
            title = "Device Admin",
            description = "Required to detect wrong lockscreen PIN unlock attempts for anti-theft.",
            icon = Icons.Default.Security,
            isGranted = isDeviceAdminActive,
            onAction = {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Monitors wrong lockscreen attempts to sound siren and capture intruder selfie.")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        ),
        PermissionItem(
            title = "Draw Over Apps (Overlay)",
            description = "Allows Max Assistant to display voice visualizer and prompts over apps.",
            icon = Icons.Default.Layers,
            isGranted = hasOverlayPermission,
            onAction = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            }
        ),
        PermissionItem(
            title = "Battery Optimization Exemption",
            description = "Prevents system from killing the always-listening service in background.",
            icon = Icons.Default.BatteryChargingFull,
            isGranted = isIgnoringBatteryOptimizations,
            onAction = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            }
        ),
        PermissionItem(
            title = "OEM Autostart (Vivo/Oppo/Xiaomi)",
            description = "Ensures wake word listening stays active without being frozen by OEM managers.",
            icon = Icons.Default.Speed,
            isGranted = true, // Informational / direct intent
            onAction = {
                val oemIntents = listOf(
                    Intent().setComponent(ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                    Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                    Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                )
                for (intent in oemIntents) {
                    try {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        break
                    } catch (e: Exception) {
                        // try next
                    }
                }
            }
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("PERMISSIONS ONBOARDING", fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 16.sp)
                Text("Grant permissions for full hands-free phone control", color = TextSecondary, fontSize = 12.sp)
            }
            Button(
                onClick = onFinished,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Continue", color = CyberNavy, fontWeight = FontWeight.Bold)
            }
        }

        // List cards
        for (item in permissionsList) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (item.isGranted) EmeraldGreen.copy(alpha = 0.3f) else BrightCoral.copy(alpha = 0.4f),
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (item.isGranted) EmeraldGreen.copy(alpha = 0.15f) else BrightCoral.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                item.icon,
                                contentDescription = item.title,
                                tint = if (item.isGranted) EmeraldGreen else BrightCoral,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                if (item.isGranted) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Granted", tint = EmeraldGreen, modifier = Modifier.size(14.dp))
                                } else {
                                    Icon(Icons.Default.Warning, contentDescription = "Required", tint = BrightCoral, modifier = Modifier.size(14.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(item.description, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = item.onAction,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (item.isGranted) DarkSapphire else BrightCoral
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (item.isGranted) "Settings" else "Grant",
                            color = if (item.isGranted) NeonCyan else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
