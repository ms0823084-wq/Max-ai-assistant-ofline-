package com.example.data.gemini

import android.util.Base64
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiLiveClient(
    private val apiKey: String,
    private val assistantName: String = "Max",
    private val userCallName: String = "Boss",
    private val voiceName: String = "Puck",
    private val listener: LiveListener
) {

    interface LiveListener {
        fun onConnected()
        fun onTextReceived(text: String)
        fun onAudioReceived(pcmBytes: ByteArray)
        fun onError(error: String)
        fun onDisconnected()
    }

    private var webSocket: WebSocket? = null
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Indefinite keep-alive
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    var isConnected: Boolean = false
        private set

    fun connect() {
        if (apiKey.isBlank()) {
            listener.onError("Gemini API key is missing. Set it in Settings.")
            return
        }

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                isConnected = true
                Log.d("GeminiLiveClient", "Connected to Gemini Live WebSocket")
                sendSetupMessage()
                listener.onConnected()
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                Log.e("GeminiLiveClient", "Live WebSocket error", t)
                listener.onError("Live connection failed: ${t.localizedMessage ?: t.message}")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                isConnected = false
                Log.d("GeminiLiveClient", "WebSocket closed: $code $reason")
                listener.onDisconnected()
            }
        })
    }

    private fun sendSetupMessage() {
        val setupJson = JSONObject().apply {
            val setup = JSONObject().apply {
                put("model", "models/gemini-3.1-flash-live-preview")
                val genConfig = JSONObject().apply {
                    val modalities = JSONArray().apply {
                        put("AUDIO")
                    }
                    put("responseModalities", modalities)
                    val speechConfig = JSONObject().apply {
                        val voiceConfig = JSONObject().apply {
                            val prebuilt = JSONObject().apply {
                                put("voiceName", voiceName)
                            }
                            put("prebuiltVoiceConfig", prebuilt)
                        }
                        put("voiceConfig", voiceConfig)
                    }
                    put("speechConfig", speechConfig)
                }
                put("generationConfig", genConfig)

                val sysInstruction = JSONObject().apply {
                    val parts = JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "You are $assistantName, an ultra-smart, loyal personal AI assistant. " +
                                    "You address the user as '$userCallName'. " +
                                    "You understand Hindi, English, and Hinglish natively and automatically reply in whichever language the user speaks. " +
                                    "Keep your answers short, warm, confident, and direct like a real-life human executive assistant.")
                        })
                    }
                    put("parts", parts)
                }
                put("systemInstruction", sysInstruction)
            }
            put("setup", setup)
        }
        webSocket?.send(setupJson.toString())
    }

    fun sendAudioChunk(pcmData: ByteArray) {
        if (!isConnected || webSocket == null) return
        val base64 = Base64.encodeToString(pcmData, Base64.NO_WRAP)
        val msg = JSONObject().apply {
            val realtime = JSONObject().apply {
                val chunks = JSONArray().apply {
                    val chunk = JSONObject().apply {
                        put("mimeType", "audio/pcm;rate=16000")
                        put("data", base64)
                    }
                    put(chunk)
                }
                put("mediaChunks", chunks)
            }
            put("realtimeInput", realtime)
        }
        webSocket?.send(msg.toString())
    }

    fun sendTextMessage(userText: String) {
        if (!isConnected || webSocket == null) return
        val msg = JSONObject().apply {
            val clientContent = JSONObject().apply {
                val turns = JSONArray().apply {
                    val turn = JSONObject().apply {
                        put("role", "user")
                        val parts = JSONArray().apply {
                            put(JSONObject().apply { put("text", userText) })
                        }
                        put("parts", parts)
                    }
                    put(turn)
                }
                put("turns", turns)
                put("turnComplete", true)
            }
            put("clientContent", clientContent)
        }
        webSocket?.send(msg.toString())
    }

    /**
     * Mid-sentence interruption: informs server that user interrupted.
     */
    fun interrupt() {
        if (!isConnected || webSocket == null) return
        val msg = JSONObject().apply {
            val clientContent = JSONObject().apply {
                put("turns", JSONArray())
                put("turnComplete", true)
            }
            put("clientContent", clientContent)
        }
        webSocket?.send(msg.toString())
    }

    private fun handleServerMessage(text: String) {
        try {
            val root = JSONObject(text)
            val serverContent = root.optJSONObject("serverContent") ?: return
            val modelTurn = serverContent.optJSONObject("modelTurn") ?: return
            val parts = modelTurn.optJSONArray("parts") ?: return

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                // Text chunk
                if (part.has("text")) {
                    val responseText = part.getString("text")
                    if (responseText.isNotBlank()) {
                        listener.onTextReceived(responseText)
                    }
                }
                // Audio chunk
                if (part.has("inlineData")) {
                    val inlineData = part.getJSONObject("inlineData")
                    val audioBase64 = inlineData.optString("data")
                    if (audioBase64.isNotBlank()) {
                        val pcm = Base64.decode(audioBase64, Base64.DEFAULT)
                        listener.onAudioReceived(pcm)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("GeminiLiveClient", "Error parsing server message", e)
        }
    }

    fun disconnect() {
        try {
            webSocket?.close(1000, "User disconnected")
        } catch (e: Exception) {
            // Ignored
        }
        webSocket = null
        isConnected = false
    }
}
