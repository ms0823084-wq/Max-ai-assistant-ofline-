package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.MaxApplication
import com.example.R
import com.example.speech.SpeechManager

class VoiceForegroundService : Service(), SpeechManager.SpeechEventsListener {

    companion object {
        const val CHANNEL_ID = "max_voice_service_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_LISTENING = "com.example.action.START_LISTENING"
        const val ACTION_STOP_LISTENING = "com.example.action.STOP_LISTENING"
        const val ACTION_TOGGLE_LISTENING = "com.example.action.TOGGLE_LISTENING"

        var isRunning = false
            private set
    }

    private var speechManager: SpeechManager? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val app = applicationContext as MaxApplication
        speechManager = SpeechManager(this, app.securityManager, this, requireWakeWord = true)
        speechManager?.shouldIgnore = { app.ttsManager.isSpeaking }
        speechManager?.initialize()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = applicationContext as MaxApplication
        val action = intent?.action

        when (action) {
            ACTION_STOP_LISTENING -> {
                stopListeningService()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_LISTENING -> {
                if (isRunning) {
                    stopListeningService()
                    return START_NOT_STICKY
                } else {
                    startForegroundWithNotification()
                    speechManager?.enableAlwaysListening()
                    app.securityManager.isListeningActive = true
                    isRunning = true
                }
            }
            else -> {
                startForegroundWithNotification()
                speechManager?.enableAlwaysListening()
                app.securityManager.isListeningActive = true
                isRunning = true
            }
        }

        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val app = applicationContext as MaxApplication
        val wakeWord = app.securityManager.wakeWord
        val assistantName = app.securityManager.assistantName

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pOpenIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, VoiceForegroundService::class.java).apply {
            this.action = ACTION_STOP_LISTENING
        }
        val pStopIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("$assistantName Assistant Active")
            .setContentText("Listening for \"$wakeWord\" • Controlling your phone hands-free")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pOpenIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Turn Off", pStopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun stopListeningService() {
        val app = applicationContext as MaxApplication
        isRunning = false
        app.securityManager.isListeningActive = false
        speechManager?.stopListening()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Max Voice Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground service maintaining hands-free wake word detection and phone control"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onWakeWordDetected(keyword: String) {
        val app = applicationContext as MaxApplication
        val boss = app.securityManager.userCallName
        app.ttsManager.speak("Haanji $boss, bataiye?")
    }

    override fun onCommandRecognized(command: String) {
        val app = applicationContext as MaxApplication
        app.phoneCommander.processVoiceCommand(command)
    }

    override fun onPowerStateChanged(isOn: Boolean) {
        val app = applicationContext as MaxApplication
        val name = app.securityManager.assistantName
        val boss = app.securityManager.userCallName
        app.ttsManager.speak(if (isOn) "Haanji $boss, $name on ho gaya." else "$name off ho gaya.")
    }

    override fun onPartialSpeech(partial: String) {}

    override fun onRmsChanged(rmsDb: Float) {}

    override fun onSpeechError(error: String) {}

    override fun onListeningStateChanged(isListening: Boolean) {}

    override fun onDestroy() {
        super.onDestroy()
        speechManager?.destroy()
        isRunning = false
        val app = applicationContext as MaxApplication
        app.securityManager.isListeningActive = false
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
