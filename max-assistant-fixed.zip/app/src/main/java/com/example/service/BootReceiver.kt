package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.MaxApplication

/** Restarts hands-free listening after the phone reboots (if it was on). Android may block this; see Quick Settings tile. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            ReminderManager.rescheduleAll(context)
        } catch (e: Exception) {
            // ignore
        }
        val app = context.applicationContext as MaxApplication
        if (!app.securityManager.isListeningActive) return
        try {
            ContextCompat.startForegroundService(context, Intent(context, VoiceForegroundService::class.java))
        } catch (e: Exception) {
            // Android 14/15 can refuse to start a microphone service from boot.
        }
    }
}
