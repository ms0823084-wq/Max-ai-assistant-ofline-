package com.example.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.ui.components.AvatarState
import java.util.Locale

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var onInitCallback: (() -> Unit)? = null

    var isSpeaking: Boolean = false
        private set

    private var baseSpeed = 1.0f
    private var basePitch = 1.0f
    private var emotionActive = false

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    isSpeaking = true
                }

                override fun onDone(utteranceId: String?) {
                    isSpeaking = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                }
            })
            // Default to Hindi or Indian English
            val hiLocale = Locale("hi", "IN")
            val result = tts?.setLanguage(hiLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }
            onInitCallback?.invoke()
            Log.d("TtsManager", "TTS initialized successfully")
        } else {
            Log.e("TtsManager", "TTS init failed with code $status")
        }
    }

    fun applySettings(gender: String, speed: Float, pitch: Float) {
        baseSpeed = speed
        basePitch = pitch
        tts?.setSpeechRate(speed)
        tts?.setPitch(pitch)

        // Select voice gender if available
        try {
            val voices = tts?.voices ?: return
            val preferredVoice = voices.firstOrNull { voice ->
                val name = voice.name.lowercase()
                val isGenderMatch = if (gender.equals("Female", ignoreCase = true)) {
                    name.contains("female") || name.contains("fem") || name.contains("#female")
                } else {
                    name.contains("male") && !name.contains("female")
                }
                isGenderMatch && (voice.locale.language == "hi" || voice.locale.language == "en")
            }
            if (preferredVoice != null) {
                tts?.voice = preferredVoice
            }
        } catch (e: Exception) {
            Log.w("TtsManager", "Could not apply voice selection", e)
        }
    }

    /**
     * Speaks text immediately. Stops any previous utterance first.
     */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isInitialized || text.isBlank()) return
        stop() // interrupt previous speech immediately
        if (!emotionActive) {
            tts?.setSpeechRate(baseSpeed)
            tts?.setPitch(basePitch)
            AvatarState.autoFrom(text)
        }

        val detectedLocale = if (isHindiText(text)) Locale("hi", "IN") else Locale("en", "IN")
        try {
            tts?.language = detectedLocale
        } catch (e: Exception) {
            // keep existing language
        }

        val utteranceId = "utterance_${System.currentTimeMillis()}"
        if (onDone != null) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { isSpeaking = true }
                override fun onDone(id: String?) {
                    isSpeaking = false
                    onDone()
                }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    isSpeaking = false
                    onDone()
                }
            })
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    /** Speaks with a feeling: voice speed and pitch change with the emotion, and the character's face follows. */
    fun speakWithEmotion(text: String, emotion: String, speed: Float = baseSpeed, pitch: Float = basePitch) {
        AvatarState.setManual(emotion)
        val (sf, pf) = when (emotion.lowercase()) {
            "happy" -> 1.05f to 1.08f
            "sad" -> 0.9f to 0.9f
            "angry" -> 1.1f to 0.95f
            "surprised" -> 1.1f to 1.15f
            "love" -> 0.95f to 1.05f
            "sleepy" -> 0.85f to 0.9f
            "thinking" -> 0.95f to 1.0f
            else -> 1.0f to 1.0f
        }
        tts?.setSpeechRate(speed * sf)
        tts?.setPitch(pitch * pf)
        emotionActive = true
        speak(text)
        emotionActive = false
    }

    /**
     * Mid-sentence interruption.
     */
    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Ignored
        }
        isSpeaking = false
    }

    private fun isHindiText(text: String): Boolean {
        // Checks for Devanagari Unicode block
        for (char in text) {
            if (char.code in 0x0900..0x097F) return true
        }
        return false
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignored
        }
    }
}
